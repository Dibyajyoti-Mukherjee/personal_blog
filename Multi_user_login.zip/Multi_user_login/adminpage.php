<?php
session_start();

include('connection.php');

$sql = "SELECT * from data";
$query = mysqli_query($con, $sql);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
  <style>
    body{ 
    background-image: url("admin.jpg");
    height: 200%;
    width: 100%;
    background-size: cover;
}
.row{
  opacity: 80%;
}
  </style>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="admindesign.css">
  <script type="text/javascript">
        function preventBack(){window.history.forward()};
        setTimeout("preventBack()",0);
          window.onunload=function(){null;}
    </script>
</head>
<body>
<div class="container mt-5">
  <?php if(isset($_REQUEST['info'])){?>
    <?php if($_REQUEST['info'] == "deleted"){?>

                    <div class="alert alert-danger" role="alert">
                    Deleted successfully
                </div>

                <?php }?>

            <?php }?>
 
<div class="text-center">
 <a href="bloglogic.php"><button class="green button"><i class="fa fa-plus"></i> Add Post</button></a>
 <a href="dashboard.php"><button class="blue button"><i class="fa fa-sign-out"></i>Back</button></a>
</div>

     <div class="row">
       
      <?php foreach($query as $q){?>
      	<div class="col-4 d-flex justify-content-center align-items-center">
           <div class="card text-white bg-dark mt-5">
        	 <div class="card-body" style="width: 18rem;">
        	 	<h5 class="card-title"><?php echo $q['blogtitle'];?></h5>
              <div class="d-flex mt-2 justify-content-center align-items-center">
                
                <a href="update_data.php?id=<?php echo $q['id'];?>"><button class="green button"><i class="fa fa-edit"></i>Update</button></a>
                <form method="post" action="delete_data.php">
                   
                   <input type="text" hidden name="id" value="<?php echo $q["id"];?>">
                   <button class="red button" name="delete"><i class="fa fa-trash"></i> Delete</button>
                  
                </form>
                
              </div>

              <div class="d-flex mt-2 justify-content-center align-items-center">
                <a href="view.php?id=<?php echo $q['id'];?>" class="small button">Read More <span class="text-danger">&rarr;</span></a>
              </div>

        	 	   

           </div>
        </div>
   </div>
<?php }?>
</div>
</div>
<!--Bootstrap JS --->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>