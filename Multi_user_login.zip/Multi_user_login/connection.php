<?php      
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "database1";  
      
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
    $sql = "SELECT * FROM data";
    $query = mysqli_query($con, $sql);
    @$blogtitle = $_POST['blogtitle'];
    @$description = $_POST['description']; 
    @$catagory = $_POST['catagory'];
    @$id = $_POST['id'];
?>  