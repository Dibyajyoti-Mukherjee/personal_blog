<?php
 
	require_once 'conn.php';
 
	if(ISSET($_REQUEST['trash_id'])){
		$trash_id = $_REQUEST['trash_id'];
		$query=mysqli_query($conn, "SELECT * FROM `data` WHERE `id` = 'id'") or die(mysqli_error());
		$fetch=mysqli_fetch_array($query);
 
		mysqli_query($conn, "INSERT INTO `member` VALUES('', '$fetch[firstname]', '$fetch[lastname]', '$fetch[age]', '$fetch[address]')") or die(mysqli_error());
		mysqli_query($conn, "DELETE FROM `trash` WHERE `trash_id` = '$trash_id'") or die(mysqli_error());
		header('location:index.php');
	}
 
?>