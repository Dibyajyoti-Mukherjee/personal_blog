<?php 
include('connection.php');
$role = $_POST['role'];
@$username = $_POST['username'];
@$password = $_POST['password']; 
$sql = "INSERT INTO userslog (role,username) 
VALUES ('$role','$username')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
     header("location:dashboard.php");
     exit();
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
?>