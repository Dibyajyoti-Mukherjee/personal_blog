<?php      
    session_start();
    include('connection.php');  
    @$username = $_POST['username'];  
    @$password = $_POST['password']; 
    @$role = $_POST['role']; 
    //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $role = stripcslashes($role);
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password); 
        $role = mysqli_real_escape_string($con, $role); 
      
        $sql = "select *from userslog where username = '$username' and password = '$password' and role = '$role'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          if($count > 0){
             $_SESSION["username"] = $row['username'];
             $_SESSION["password"] = $row['password'];
             $_SESSION["role"] = $row['role'];
            if($role == "admin")
            {
                header("location:dashboard.php");
                exit();
            }  
            else if($role == "user")
            {
                header("location:user.php");
                exit();

            } 
        }
        else{
            header("location:index.php?info=added");
        }
?>  