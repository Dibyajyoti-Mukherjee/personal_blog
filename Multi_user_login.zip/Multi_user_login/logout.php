<?php
session_start();
unset($_SESSION["username"]);
unset($_SESSION["password"]);
unset($_SESSION["role"]);
header("Location: index.php");
session_destroy();
?>