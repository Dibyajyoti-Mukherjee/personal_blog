<?php
include("connection.php");
$sql ="DELETE FROM data"; 
if(isset($_REQUEST['delete'])){
	$id = $_REQUEST['id'];

	$sql = "DELETE FROM data WHERE id = $id"; 
	$query = mysqli_query($con,$sql);
	header("location:adminpage.php?info=deleted");
	exit();
}
?>