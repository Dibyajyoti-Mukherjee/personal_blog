<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Login Page</title>
    <script type="text/javascript">
        function preventBack(){window.history.forward()};
        setTimeout("preventBack()",0);
          window.onunload=function(){null;}
    </script>
</head>
<body>
<form action="validate.php" method="post">
        <div class="login-box">

            <h1>Login</h1>
           <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                <input type="text" placeholder="Username"
                         name="username" value="" required>
            </div>
           <div class="textbox">
                <i class="fa fa-lock" aria-hidden="true"></i>
                <input type="password" placeholder="Password"
                         name="password" value="" required>
            </div>
            <select name="role">  
             <option value="choose" selected>Choose</option>
             <option value="user">User</option>
             <option value="admin">Admin</option>
            </select>
            <br><br>
            <?php if(isset($_REQUEST['info'])){?>
    <?php if($_REQUEST['info'] == "added"){?>

                    <div class="alert alert-danger" role="alert">
                    *Invalid credential
                </div>

                <?php }?>

            <?php }?>
 
            <input class="button" type="submit"
                     name="login" value="Sign In">
                     
         </div>
    </form>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>