<?php 

include('connection.php');
if(isset($_REQUEST['update_post'])){
  $id = $_REQUEST["id"];
  $blogtitle = $_REQUEST["blogtitle"];
  $description = $_REQUEST["description"];
    
    $sql = "UPDATE data set blogtitle = '$blogtitle', description ='$description' WHERE id = $id ";
    mysqli_query($con, $sql);

    header("location:adminpage.php?info=updated");
    exit();
}


?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bloglogic.css">
</head>
<body>
  <div class="container mt-5">
    <h2><a href="adminpage.php">Back</a></h2>
    <?php foreach($query as $q){?>
    
    <form action="#" method="post">
      
        <div class="login-box">
            <h1>Update Blog</h1>
 
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
               <label>Change title</label><input type="text" name="blogtitle">
            </div>
            <div class="textbox">
                <i class="fa fa-lock" aria-hidden="true"></i>
                <label>Change description</label><input type="textarea" name="description">
                 
            </div>
            <div class="textbox">
          <label>Change catagory</label><input type="text" name="catagory" value="">
        </div>
            <input class="button" type="submit"
                     name="update_post" value="Update">
        </div>
        
    </form>
      <?php }?>
 
    

  </div>

<!--Bootstrap JS --->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>