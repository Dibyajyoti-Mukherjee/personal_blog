<?php
include('connection.php'); 
@$day = $_POST['day'];

$sql = "INSERT INTO data (blogtitle,description,day,catagory) 
VALUES ('$blogtitle','$description','$day','$catagory')";

if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
     header("location:adminpage.php");
     exit();
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
?>