<?php
session_start();

include('connection.php');

$sql = "SELECT * FROM data";
$query = mysqli_query($con, $sql);
$count = mysqli_num_rows($query);

?>
<!DOCTYPE html>
<html>
<head>
	<title>User</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="userdesign.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <script type="text/javascript">
        function preventBack(){window.history.forward()};
        setTimeout("preventBack()",0);
          window.onunload=function(){null;}
    </script>
</head>
<body>
<div class="container mt-5">
    <?php if($count == 0){?>

                    <div class="alert alert-danger" role="alert" id="alrt">
                    No blogs adeed by admin
                </div>

                <?php }?>

  <div class="text-center">
   <button class="blue button"><a href="logout.php"><i class="fa fa-sign-out"></i>logout</a></button>
</div>
     <div class="row">
       
      <?php foreach($query as $q){?>
      	<div class="col-4 d-flex justify-content-center align-items-center">
           <div class="card text-white bg-dark mt-5">
        	 <div class="card-body" style="width: 18rem;">
        	 	<h5 class="card-title"><?php echo $q['blogtitle'];?></h5>
        	 	   <a href="user_view.php?id=<?php echo $q['id'];?>" class="btn btn-light">Read More <span class="text-danger">&rarr;</span></a>

           </div>
        </div>
   </div>
<?php }?>
</div>
</div>
<!--Bootstrap JS --->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>