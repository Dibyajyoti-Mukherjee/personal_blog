<!DOCTYPE html>
<html>
<head>
	<title>Create blog</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="bloglogic.css">
</head>
<body>
     <h4><a href="adminpage.php">Back</a></h4>
	<form action="blog_add.php" method="post">
        <div class="login-box">
            <h1>Add Blog</h1>
 
            <div class="textbox">
                <i class="fa fa-user" aria-hidden="true"></i>
                <input type="text" placeholder="Title"
                         name="blogtitle" value="" required>
            </div>
            <div class="textbox">
                <i class="fa fa-lock" aria-hidden="true"></i>
                 <input type="textarea" id="description" placeholder="Add description" name="description" value="" required>
                 
            </div>
            <div class="textbox">
            <input type="date" name="day" required pattern="\d{4}-\d{2}-\d{2}" required>
        </div>
        <div class="textbox">
            <input type="text" name="catagory" placeholder="Category" name="catagory" value="" required>
        </div>
            <input class="button" type="submit"
                     name="new_post" value="Add">
        </div>
    </form>
    <!--Bootstrap JS --->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>