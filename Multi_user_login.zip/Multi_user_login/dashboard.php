<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<style>
		*{
			margin: 0px;
			padding: 0px;
		}
		body{
			background-image: url("admin.jpg");
			background-size: cover;
			background-repeat: no-repeat;
		}
		#ab{
			align-items: center;
			margin-left: 45%;
			color: blue;
		}
	</style>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="dash_design.css">
</head>
<body>
<nav>
	<br><br><br><br>
   <a href="adminpage.php"><h4>All blogs</h4></a><br><br><br><br>
   <a href="logout.php"><i class="fa fa-sign-out"></i></a><br><br><br><br>
   <a href="Add_user.php"><i class="fa fa-user"></i><h4>Add_user</h4></a>
 </nav>
 <h4 id="ab"><i class="fa fa-dashboard"></i>|Dashboard|</h4>
</body>
</html>