<!DOCTYPE html>
<html>
<head>
	<title>deleted</title>
	<link rel="stylesheet" type="text/css" href="admindesign.css">
</head>
<body>
<a href="dashboard.php"><button class="blue button"><i class="fa fa-sign-out"></i>Go back</button></a>
</body>
</html>